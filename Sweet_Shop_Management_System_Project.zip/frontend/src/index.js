
import React from 'react';
import { createRoot } from 'react-dom/client';

function App() {
  return (
    <div>
      <h1>Sweet Shop Management System</h1>
      <p>Frontend connected to backend APIs</p>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
