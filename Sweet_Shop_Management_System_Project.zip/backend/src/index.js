
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const db = new sqlite3.Database('./database.db');
const SECRET = 'secretkey';

db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, role TEXT)");
  db.run("CREATE TABLE IF NOT EXISTS sweets (id INTEGER PRIMARY KEY, name TEXT, category TEXT, price REAL, quantity INTEGER)");
});

function auth(req, res, next) {
  const token = req.headers.authorization;
  if (!token) return res.sendStatus(401);
  jwt.verify(token, SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

app.post('/api/auth/register', (req, res) => {
  const { username, password } = req.body;
  const hash = bcrypt.hashSync(password, 8);
  db.run("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
    [username, hash, 'USER'],
    () => res.json({ message: 'Registered' })
  );
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  db.get("SELECT * FROM users WHERE username = ?", [username], (err, user) => {
    if (!user) return res.sendStatus(401);
    if (!bcrypt.compareSync(password, user.password)) return res.sendStatus(401);
    const token = jwt.sign({ id: user.id, role: user.role }, SECRET);
    res.json({ token });
  });
});

app.get('/api/sweets', auth, (req, res) => {
  db.all("SELECT * FROM sweets", [], (err, rows) => res.json(rows));
});

app.post('/api/sweets', auth, (req, res) => {
  const { name, category, price, quantity } = req.body;
  db.run("INSERT INTO sweets (name, category, price, quantity) VALUES (?, ?, ?, ?)",
    [name, category, price, quantity],
    () => res.json({ message: 'Sweet added' })
  );
});

app.post('/api/sweets/:id/purchase', auth, (req, res) => {
  db.run("UPDATE sweets SET quantity = quantity - 1 WHERE id = ? AND quantity > 0",
    [req.params.id],
    () => res.json({ message: 'Purchased' })
  );
});

app.listen(4000, () => console.log('Backend running on port 4000'));
