
# Sweet Shop Management System

## Description
Full-stack Sweet Shop Management System built as per AI Kata requirements.

## Tech Stack
- Backend: Node.js, Express, SQLite, JWT
- Frontend: React

## How to Run
### Backend
```bash
cd backend
npm install
npm start
```

### Frontend
```bash
cd frontend
npm install
npm start
```

## My AI Usage
I used ChatGPT to design architecture, generate boilerplate code,
and ensure alignment with the provided problem statement.
I manually reviewed and customized all logic.
